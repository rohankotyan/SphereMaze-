#!/usr/bin/env bash
# Downloads three.js (pinned) into the app assets so the game works fully offline.
set -euo pipefail
V=0.179.1
D="$(dirname "$0")/../app/src/main/assets"
curl -fsSL "https://cdn.jsdelivr.net/npm/three@$V/build/three.module.js" -o "$D/three.module.js"
curl -fsSL "https://cdn.jsdelivr.net/npm/three@$V/build/three.core.js"   -o "$D/three.core.js"
echo "three.js $V saved to $D"
