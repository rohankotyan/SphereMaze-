# Maze Sphere – Android

## Install on your phone (fastest)
1. Push this folder to a GitHub repo (this folder = repo root).
2. Actions tab → "Build Maze Sphere" → Run workflow.
3. Download the `MazeSphere-APK` artifact, unzip, copy `app-debug.apk` to your phone, open it
   (allow "install unknown apps").

## Or build locally
    ./scripts/fetch-three.sh          # downloads three.js into assets (needed once)
    # open this folder in Android Studio and press Run

## Publish to Google Play
1. Create a Play Console account (one-time $25).
2. Create a signing key once and KEEP IT SAFE:
       keytool -genkey -v -keystore release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias mazesphere
3. In GitHub → Settings → Secrets, add: KEYSTORE_BASE64 (`base64 -w0 release.jks`),
   KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD.
4. Run the workflow again → download `MazeSphere-AAB` → upload `app-release.aab` in Play Console
   (enable Play App Signing).
5. Listing needs: 512×512 icon, 1024×500 feature graphic, 2+ phone screenshots, short/full
   description, a privacy policy URL (the app collects no data), content rating, Data safety form.
6. New personal accounts must run a closed test with 12+ testers for 14 days before production.

Change `applicationId` (`com.rohan.mazesphere`) in app/build.gradle before publishing if you want
your own package name – it can never change after release.
